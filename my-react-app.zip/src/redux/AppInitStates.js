const AppInitStates = {
  // 初始化登录状态(未登录)
  login: false
}

export default AppInitStates
