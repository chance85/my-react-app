export const loadInitState = {
  // 默认已加载
  loading: false
}