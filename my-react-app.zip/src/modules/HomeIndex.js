import React, { Component } from 'react'

class HomeIndex extends Component {
  render() {
    return <div>这里是homeindex主页</div>
  }
}

export default HomeIndex
