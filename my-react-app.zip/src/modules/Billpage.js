import React, { Component } from 'react';

class Billpage extends Component {
  render() {
    return (
      <div>
        这是Bill页面
      </div>
    );
  }
}

export default Billpage;