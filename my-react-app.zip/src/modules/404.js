import React, { Component } from 'react'

class Is404 extends Component {
  render() {
    return <div style={{ textAlign: 'center' }}>亲, 您访问的页面不存在!</div>
  }
}

export default Is404
